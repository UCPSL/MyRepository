//
//  Store.m
//  ThirdKu1
//
//  Created by ad  on 15-3-27.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "Store.h"


@implementation Store

@dynamic storeID;
@dynamic storeName;
@dynamic storeImg;

@end
