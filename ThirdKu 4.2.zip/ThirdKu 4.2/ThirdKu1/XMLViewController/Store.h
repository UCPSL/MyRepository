//
//  Store.h
//  ThirdKu1
//
//  Created by ad  on 15-3-27.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Store : NSManagedObject

@property (nonatomic, retain) NSString * storeID;
@property (nonatomic, retain) NSString * storeName;
@property (nonatomic, retain) NSString * storeImg;

@end
