//
//  Story.m
//  ThirdKu1
//
//  Created by ad  on 15-3-26.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "Story.h"


@implementation Story

@dynamic storyID;
@dynamic storyName;
@dynamic sotryContent;
@dynamic storyImg;


-(instancetype)init
{
    if (self = [super init]) {
    }
    return self;
}


@end
