//
//  messageCell.h
//  ThirdKu1
//
//  Created by ad  on 15-3-26.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, BRFlabbyHighlightState){
    BRFlabbyHighlightStateNone,
    BRFlabbyHighlightStateCellAboveTouched,
    BRFlabbyHighlightStateCellBelowTouched,
    BRFlabbyHighlightStateCellTouched
};




@interface messageCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *storyID;
@property (strong, nonatomic) IBOutlet UILabel *storyName;
@property (strong, nonatomic) IBOutlet UILabel *storyContent;
@property (strong, nonatomic) IBOutlet UIImageView *storyImg;


#pragma mark 动态cell
@property (assign, nonatomic) CGFloat verticalVelocity;
@property (assign, nonatomic, setter = setFlabby:) BOOL isFlabby;
@property (assign, nonatomic, setter = setLongPressAnimated:) BOOL                    longPressIsAnimated;
@property (copy, nonatomic) UIColor *flabbyOverlapColor;
@property (copy, nonatomic) UIColor *flabbyColor;
@property (assign, nonatomic) BRFlabbyHighlightState  flabbyHighlightState;
@property (assign, nonatomic) CGFloat touchXLocationInCell;
@property (copy, nonatomic) UIColor *flabbyColorAbove;
@property (copy, nonatomic) UIColor *flabbyColorBelow;



@end
