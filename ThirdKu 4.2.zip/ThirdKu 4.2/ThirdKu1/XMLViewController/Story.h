//
//  Story.h
//  ThirdKu1
//
//  Created by ad  on 15-3-26.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Story : NSManagedObject

@property (nonatomic, retain) NSString * storyID;
@property (nonatomic, retain) NSString * storyName;
@property (nonatomic, retain) NSString * sotryContent;
@property (nonatomic, retain) NSString * storyImg;

@end
