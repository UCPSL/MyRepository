//
//  ArraySort.m
//  ThirdKu1
//
//  Created by ad  on 15-3-27.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "ArraySort.h"

ArraySort *arraySort = nil;

@implementation ArraySort

@synthesize oldArray;


+(ArraySort *)sharedInstance
{
    if (!arraySort) {
        arraySort = [[ArraySort alloc]init];
    }
    return arraySort;
}

-(NSArray *)oldArray
{
    if (!oldArray) {
        oldArray = [NSArray array];
    }
    return oldArray;
}




-(NSArray *)backNewArray:(NSArray *)passArray
{
    
    NSComparator finderSort = ^(id string1,id string2){
        
        if ([string1 integerValue] > [string2 integerValue]) {
            return (NSComparisonResult)NSOrderedDescending;
        }else if ([string1 integerValue] < [string2 integerValue]){
            return (NSComparisonResult)NSOrderedAscending;
        }
        else
            return (NSComparisonResult)NSOrderedSame;
    };
    
    oldArray = [passArray sortedArrayUsingComparator:finderSort];
    return oldArray;
}

@end
