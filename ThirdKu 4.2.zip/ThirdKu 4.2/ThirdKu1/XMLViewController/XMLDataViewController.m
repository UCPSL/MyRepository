//
//  XMLDataViewController.m
//  ThirdKu
//
//  Created by ad  on 15-3-25.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "XMLDataViewController.h"
#import "messageCell.h"
#import "TBXML.h"
#import "ArraySort.h"
#import "Store.h"

#import "AppDelegate.h"

@implementation XMLDataViewController
{
    UITableView *_myTabelView;
    TBXML *tbxml;
}

@synthesize context;

-(void)viewDidLoad
{
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor grayColor]];
    
    //这里需要引进自己项目的委托，是让全局managedObjectContext起作用。
    AppDelegate *delegate = [[UIApplication sharedApplication]delegate];
    self.context = delegate.managedObjectContext;
   
    [self addXmlDataSource];
    [self addPlistCoreData];
    [self addMyTabelView];
    
//    [self delete];
    
    [self fetchRequest];
    
    
    
}


#pragma mark 数组排序
-(void)addPlistCoreData
{
    NSString *areaName = [[NSBundle mainBundle]pathForResource:@"area" ofType:@"plist"];
    NSDictionary *areaAllData = [NSDictionary dictionaryWithContentsOfFile:areaName];
    
    NSArray *areaKeys = [NSArray arrayWithArray:areaAllData.allKeys];
    NSArray *newArray = [[ArraySort sharedInstance]backNewArray:areaKeys];
    NSLog(@"%@",newArray);//按数字大小排序 从小到大。
    
    NSArray *areaKeys1 = [NSArray arrayWithObjects:@"qtc",@"fqc",@"aoc",@"fzc",@"dec", nil];
    NSArray *_sortedArray= [areaKeys1 sortedArrayUsingSelector:@selector(compare:)];
    NSLog(@"%@",_sortedArray);//按字母先后排序 从A到Z。
    
    //数组中的字典排序
    NSMutableArray *ary = [NSMutableArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:@"ZhangSan",@"name", @"23",@"age",nil], nil];
    
    [ary addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"LiSi",@"name", @"26",@"age",nil]];
    [ary addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"WangWu",@"name", @"20",@"age",nil]];
    [ary addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"TaiLiu",@"name", @"29",@"age",nil]];
    
    NSSortDescriptor *_sorter = [[NSSortDescriptor alloc] initWithKey:@"name"
                                                             ascending:YES];
    NSSortDescriptor *_sorter1 = [[NSSortDescriptor alloc] initWithKey:@"age"
                                                             ascending:YES];
    
    NSLog(@"未排序:\n%@",ary);
    NSLog(@"根据name排序:\n%@",[ary sortedArrayUsingDescriptors:[NSArray arrayWithObjects:_sorter, nil]]);
    NSLog(@"根据age排序:\n%@",[ary sortedArrayUsingDescriptors:[NSArray arrayWithObjects:_sorter1, nil]]);
}


-(void)addXmlDataSource
{
    
    //先判断表里是否有数据，如果表为空则添加数据
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Store"inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSUInteger cout = [context countForFetchRequest:fetchRequest error:&error];
    NSLog(@"%d",cout);
    

    NSString *xmlFile = [[NSBundle mainBundle]pathForResource:@"Product_Full" ofType:@"xml"];
    NSData *xmlData = [NSData dataWithContentsOfFile:xmlFile];
    tbxml = [[TBXML alloc]initWithXMLData:xmlData];
    
    TBXMLElement *root = tbxml.rootXMLElement;
    if (root) {
        TBXMLElement *row = [TBXML childElementNamed:@"product" parentElement:root];
        if (row) {
            _message = [[NSMutableArray alloc]init];
            while (row) {
                
                TBXMLElement *p1 = [TBXML childElementNamed:@"productId" parentElement:row];
                TBXMLElement *p2 = [TBXML childElementNamed:@"productNameCn" parentElement:row];
                TBXMLElement *p3 = [TBXML childElementNamed:@"ingredientsCn" parentElement:row];
                TBXMLElement *p4 = [TBXML childElementNamed:@"image" parentElement:row];
                
                NSDictionary *items = [NSDictionary dictionaryWithObjectsAndKeys:[TBXML textForElement:p1],@"productId",[TBXML textForElement:p2],@"productNameCn",[TBXML textForElement:p3],@"ingredientsCn",[TBXML textForElement:p4],@"image", nil];
                
                //判断表是否有数据，无数据时添加
                if (cout == 0) {
                    Store *store = [NSEntityDescription insertNewObjectForEntityForName:@"Store" inManagedObjectContext:context];
                    store.storeID = [TBXML textForElement:p1];
                    store.storeName = [TBXML textForElement:p2];
                    store.storeImg = [TBXML textForElement:p4];
                    NSError *error;
                    if(![context save:&error])
                    {
                        NSLog(@"不能保存：%@",[error localizedDescription]);
                    }
                }

                [_message addObject:items];
                row = row->nextSibling;
            }
        }
    }
}


-(void)fetchRequest
{
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Store"inManagedObjectContext:context];
    [fetchRequest setEntity:entity];
    
    NSError *error;
    NSUInteger cout = [context countForFetchRequest:fetchRequest error:&error];
    NSLog(@"%ld",cout);
    
    NSArray *fetchedObjects = [context executeFetchRequest:fetchRequest error:&error];
    
    NSLog(@"%ld",fetchedObjects.count);
    
    NSString *str = @"27";
    for (Store *info in fetchedObjects) {
        NSRange rang = [info.storeID rangeOfString:str];
        if (rang.length > 0) {
            NSLog(@"storyID:%@", info.storeID);
            NSLog(@"storyName:%@", info.storeName);
            NSLog(@"storyName:%@", info.storeImg);
        }
    }
    
}



-(void)delete
{
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Store" inManagedObjectContext:context];
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setIncludesPropertyValues:NO];
    [request setEntity:entity];
    NSError *error = nil;
    NSArray *datas = [context executeFetchRequest:request error:&error];
    if (!error && datas && [datas count])
    {
        for (Store *obj in datas)
        {
//            if ([obj.storeID isEqualToString:@"80414"]) {
                [context deleteObject:obj];
                NSLog(@"全部删除");
//            }
        }
        if (![context save:&error])
        {
            NSLog(@"删除失败:%@",error);
        }
    }
}



-(void)addMyTabelView
{
    _myTabelView = [[UITableView alloc]initWithFrame:self.view.frame style:UITableViewStylePlain];
    
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:self.view.frame];
    [imgView setImage:[UIImage imageNamed:@"0.jpg"]];
    [_myTabelView setBackgroundView:imgView];
    [_myTabelView setDelegate:self];
    [_myTabelView setDataSource:self];
//    [_myTabelView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"0.jpg"]]];
    [self.view addSubview:_myTabelView];
}


#pragma mark Table Data Source Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //    return [self.message count];
    return 20;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"messageCell";
    messageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if(cell == nil){
        cell = (messageCell *)[[[NSBundle mainBundle]loadNibNamed:@"messageCell" owner:nil options:nil]lastObject];
    }
    
    NSInteger row = [indexPath row];
    NSDictionary *rowData = [self.message objectAtIndex:row];
    cell.storyID.text = [rowData objectForKey:@"productId"];
    
    cell.storyName.text = [rowData objectForKey:@"productNameCn"];
    cell.storyContent.text = [rowData objectForKey:@"ingredientsCn"];
    [cell.storyImg sd_setImageWithURL:[NSURL URLWithString:[rowData objectForKey:@"image"]] placeholderImage:nil];
    [cell.storyImg.layer setCornerRadius:cell.storyImg.frame.size.width / 2];
    cell.storyImg.layer.masksToBounds = YES;
    cell.storyImg.layer.shadowOffset = CGSizeMake(-5, 5);
    cell.storyImg.layer.shadowRadius = 5;
    cell.storyImg.layer.shadowOpacity = 0.5;
    [cell setBackgroundColor:[UIColor colorWithRed:111 green:111 blue:111 alpha:0.7]];
    
    return cell;
}
#pragma mark Table Delegate Methods
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 64;
}


#pragma mark 转换成汉字
- (NSString *) changeDictionary:(NSDictionary*)dic
{
    NSString *tempStr1 = [[dic description] stringByReplacingOccurrencesOfString:@"\\u" withString:@"\\U"];
    NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    
    NSString *tempStr3 = [[@"\"" stringByAppendingString:tempStr2] stringByAppendingString:@"\""];
    NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
    NSString *str = [NSPropertyListSerialization propertyListFromData:tempData mutabilityOption:NSPropertyListImmutable format:NULL errorDescription:NULL];
    
    return str;
}

@end
