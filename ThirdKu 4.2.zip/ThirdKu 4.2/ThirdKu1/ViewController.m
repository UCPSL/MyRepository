//
//  ViewController.m
//  ThirdKu
//
//  Created by ad  on 15-3-16.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "ViewController.h"
#import "XMLDataViewController.h"
#import "ErweimaViewController.h"


//#import "MBProgressHUD.h"

@interface ViewController ()<SDWebImageManagerDelegate>
{
    SMPageControl * _myPage;
    CycleScrollView *headScroView;
    UIImageView *_headImageView;
    MONActivityIndicatorView *indicatorView;
    
    FMDatabase *db;
    NSMutableArray *allData;
    
    //    MBProgressHUD *hud;
}

@property (nonatomic , retain) NSArray *headImageArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor purpleColor]];
    
    //数组排序
    [self arraySort];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"xml解析" style:UIBarButtonItemStyleDone target:self action:@selector(xmlJump)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"二维码" style:UIBarButtonItemStyleDone target:self action:@selector(erweiJump)];
    
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"wcs_inv_20150318.15.08.676" ofType:@"csv"];
    NSString *fileContents = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *allLinedStrings = [fileContents componentsSeparatedByString:@"\r"];
    NSArray* singleStrs = [NSArray array];
    
    
    allData = [NSMutableArray arrayWithCapacity:1];
    
    for (int i = 0; i< allLinedStrings.count-1; i++) {
        NSString* strsInOneLine = [allLinedStrings objectAtIndex:i];
        //删除首尾的空格和回车
        NSString *trimmedString = [strsInOneLine stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        singleStrs = [trimmedString componentsSeparatedByString:@","];
        [allData addObject:singleStrs];
    }
    [self addFMDB];
    
    
    //拉伸图片
    UIImageView *imagView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 300, SCREEN_WIDTH, 250)];
    [imagView setBackgroundColor:[UIColor redColor]];
    UIImage *img = [UIImage imageNamed:@"0.jpg"];
    //    UIImage *img = [self OriginImage:[UIImage imageNamed:@"0.jpg"] scaleToSize:CGSizeMake(320, 250)];
    [imagView setContentMode:UIViewContentModeScaleAspectFill];
    [imagView setImage:img];
    //    imagView.clipsToBounds = YES;
    [self.view addSubview:imagView];
    
    
//    hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//    hud.labelText = @"正在请求...";
//    // mode参数可以控制显示的模式
//    //HUD.mode = MBProgressHUDModeText;
//    hud.delegate = self;
    
    
    _headImageArray = [NSArray array];
    
    //网络加载前添加指示器，数据请求完毕后隐身
    [self addZhishiqi];
    
    //判断当前网络类型
    MYLog(@"%@",[NSString stringWithFormat:@"当前网络类型为%d",[ViewController getNetworkTypeFromStatusBar]]);
    
    //添加图片测试AFN和异步加载
    [self addImage];
    
    //NSUserDefaults轻量级保存数据
    [self saveData];
    
    
    //    [self svn];
    [self svn1];
}


-(void)erweiJump
{
    [self.navigationController pushViewController:[[ErweimaViewController alloc]init] animated:YES];
}

-(void)xmlJump
{
    XMLDataViewController *xmlController = [[XMLDataViewController alloc]init];
    [self.navigationController pushViewController:xmlController animated:YES];
}

-(void)svn1{
    
    NSString *path = [[NSBundle mainBundle] pathForResource:
                      @"wcs_store_full(1)" ofType:@"csv"];
    NSString* fileContents = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"%@",fileContents);
    NSArray* allLinedStrings = [fileContents componentsSeparatedByString:@"\r"];
    
    NSArray* singleStrs = [NSArray array];
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:1];
    
    
    for (int i = 0; i< allLinedStrings.count; i++) {
        NSString* strsInOneLine = [allLinedStrings objectAtIndex:i];
        //删除首尾的空格和回车
        NSString *trimmedString = [strsInOneLine stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        singleStrs = [trimmedString componentsSeparatedByString:@","];
        [array addObject:singleStrs];
    }
    
    NSLog(@"%@",array);
    
    for (int i = 0; i<array.count -1 ; i++) {
        UILabel *lab = [[UILabel alloc]init];
        [lab setFrame:CGRectMake(0, i* (30 + 26)+200, 300, 40)];
        [self.view addSubview:lab];
        [lab setBackgroundColor:[UIColor yellowColor]];
        [lab setText:[[array objectAtIndex:i] objectAtIndex:1]];
        NSLog(@"%@",[[array objectAtIndex:i] objectAtIndex:1]);
    }
    
}




//gbk编码格式的csv文件。
-(void)svn{
    NSString *path = [[NSBundle mainBundle] pathForResource:
                      @"wcs_store_full" ofType:@"csv"];
    
    NSString* fileContents =
    [NSString stringWithContentsOfFile:path
                              encoding:CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000) error:nil];
    
    NSArray* allLinedStrings = [fileContents componentsSeparatedByString:@"\r"];
    
    NSArray* singleStrs = [NSArray array];
    
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:1];
    
    for (int i = 0; i< allLinedStrings.count; i++) {
        NSString* strsInOneLine = [allLinedStrings objectAtIndex:i];
        //删除首尾的空格和回车
        NSString *trimmedString = [strsInOneLine stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        singleStrs = [trimmedString componentsSeparatedByString:@","];
        
        NSString *tempStr1 = [trimmedString stringByReplacingOccurrencesOfString:@"\\u" withString:@"\\U"];
        NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
        NSString *tempStr3 = [[@"\"" stringByAppendingString:tempStr2] stringByAppendingString:@"\""];
        
        NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
        NSString *str = [NSPropertyListSerialization propertyListFromData:tempData mutabilityOption:NSPropertyListImmutable format:NULL errorDescription:NULL];
        
        [array addObject:str];
    }
    
    
    NSMutableArray *ary1 = [NSMutableArray array];
    NSArray *aaa = [NSArray array];
    
    for (int i = 0; i<array.count - 1; i++) {
        
        aaa = [[array objectAtIndex:i]componentsSeparatedByString:@","];
        [ary1 addObject:aaa];
    }
    
    
    if ([ary1 indexOfObject:@"深圳益田假日广场店"]) {
        NSLog(@"YESYESYES");
    }
    
    for (int i = 0; i<ary1.count; i++) {
        
        UILabel *lab = [[UILabel alloc]init];
        [lab setFrame:CGRectMake(0, i* (30 + 26)+200, 300, 40)];
        [self.view addSubview:lab];
        [lab setBackgroundColor:[UIColor yellowColor]];
        [lab setText:[[ary1 objectAtIndex:i] objectAtIndex:1]];
        
        NSLog(@"%@",[[ary1 objectAtIndex:i] objectAtIndex:1]);
    }
}


#pragma mark 判断当前网络类型
+(NETWORK_TYPE)getNetworkTypeFromStatusBar {
    
    UIApplication *app = [UIApplication sharedApplication];
    NSArray *subviews = [[[app valueForKey:@"statusBar"] valueForKey:@"foregroundView"] subviews];
    NSNumber *dataNetworkItemView = nil;
    for (id subview in subviews) {
        if([subview isKindOfClass:[NSClassFromString(@"UIStatusBarDataNetworkItemView") class]])     {
            dataNetworkItemView = subview;
            break;
        }
    }
    NETWORK_TYPE nettype = NETWORK_TYPE_NONE;
    NSNumber * num = [dataNetworkItemView valueForKey:@"dataNetworkType"];
    nettype = [num intValue];
    return nettype;
}


#pragma mark 添加图片测试AFN和异步加载
-(void)addImage
{
    NSString *baseURL = @"http://121.40.210.61";
    NSString *tail = [NSString stringWithFormat:@"/static/huandeng?kuaihua_id=%d&imei=%@",40,@"864394025917982"];
    [MyHttpTool getWithBaseURL:baseURL Path:tail params:nil success:^(id JSON) {
        
        _headImageArray = JSON[@"pics"];
        
        //下载图片
//        [self saveImg];
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 200)];
        [self.view addSubview:imageView];
        
        NSURL *imageURL = [NSURL URLWithString:[[_headImageArray objectAtIndex:1] objectForKey:@"imgurl"]];
        MYLog(@"图片地址是:%@",imageURL);
        
        [imageView sd_setImageWithURL:imageURL placeholderImage:nil];
        
        //指示器消除
        [indicatorView stopAnimating];
        
        //滚动ScroView
        [self addHeadScroView];
        
    } failure:^(NSError *error) {
        MYLog(@"网络异常,请重新加载");
        
        //10秒后重新加载
        //        [NSTimer scheduledTimerWithTimeInterval:10 target:self selector:@selector(againRequstDate) userInfo:nil repeats:NO];
    }];
}


-(void)saveData
{
    [MYSettingTool setObject:@"张三他哥" forKey:@"张三"];
    [MYSettingTool objectForKey:@"张三"];
    
    //    NSLog(@"取key为”张三“的值为:%@",[MYSettingTool objectForKey:@"张三"]);
}


//加载顶部滚动视图
-(void)addHeadScroView
{
    NSMutableArray *viewsArray = [@[] mutableCopy];
    
    headScroView = [[CycleScrollView alloc] initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, 200) animationDuration:2];
    [headScroView setDelegate:self];
    
    headScroView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.1];
    
    //创建滚动显示的ImageView
    for (int i = 0; i<_headImageArray.count; i++) {
        _headImageView = [[UIImageView alloc]initWithFrame:CGRectMake(i * self.view.frame.size.width, 64, self.view.frame.size.width, headScroView.frame.size.height)];
        NSString *imageURL = [[_headImageArray objectAtIndex:i] objectForKey:@"imgurl"];
        
        [_headImageView sd_setImageWithURL:[NSURL URLWithString:imageURL] placeholderImage:[UIImage imageNamed:@"wangyi1"]];
        
        [headScroView addSubview:_headImageView];
        [viewsArray addObject:_headImageView];
    }
    headScroView.fetchContentViewAtIndex = ^UIView *(NSInteger pageIndex){
        return viewsArray[pageIndex];
    };
    
    int con = (int)_headImageArray.count;
    headScroView.totalPagesCount = ^NSInteger(void){
        return  con;
    };
    
    
    
    
    __weak UIViewController *newViewController = self;
    headScroView.TapActionBlock = ^(NSInteger pageIndex){
        NSLog(@"点击了第%d个",pageIndex);
        
        if (pageIndex == 0) {
            Demo1ViewController *demo = [[Demo1ViewController alloc]init];
            [newViewController.navigationController pushViewController:demo animated:YES];
        }else if (pageIndex == 1){
            
            MyTabelTableViewController *mytabe = [[MyTabelTableViewController alloc]init];
            [newViewController.navigationController pushViewController:mytabe animated:YES];
            
        }else if (pageIndex == 2){
            
            [newViewController.navigationController pushViewController:[[AlertViewController alloc]init] animated:YES];
        }
        
    };
    
    [self.view addSubview:headScroView];
    [self addMyDDpage];
    
}



//加载自定义的pageView
-(void)addMyDDpage
{
    _myPage=[[SMPageControl alloc]initWithFrame:CGRectMake(0, 0, 200, 30)];
    [_myPage setCenter:CGPointMake(headScroView.frame.size.width/2, 230)];
    [_myPage setEnabled:NO];
    [_myPage setNumberOfPages:_headImageArray.count];
    [_myPage setSelected:NO];
    [self.view addSubview:_myPage];
    _myPage.indicatorMargin = 10.0f;
    _myPage.indicatorDiameter = 10.0f;
    
}

-(void)didCycleScrollView:(CycleScrollView *)cycleView ChangedPage:(NSInteger)aPage
{
    _myPage.currentPage = aPage;
}


-(void)addZhishiqi
{
    indicatorView = [[MONActivityIndicatorView alloc] init];
    indicatorView.delegate = self;
    //设置总个数
    indicatorView.numberOfCircles = 5;
    //设置大小
    indicatorView.radius = 4;
    //调节间距
    indicatorView.internalSpacing = 3;
    indicatorView.center = self.view.center;
    [indicatorView startAnimating];
    [self.view addSubview:indicatorView];
}


-(void)saveImg
{
    
    NSString *imageURL = [[_headImageArray objectAtIndex:1] objectForKey:@"imgurl"];
    
    SDWebImageManager *manager = [SDWebImageManager sharedManager];
    [manager downloadImageWithURL:[NSURL URLWithString:imageURL] options:0 progress:^(NSInteger receivedSize, NSInteger expectedSize) {
        
        NSLog(@"下载中...");
        
        
    } completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, BOOL finished, NSURL *imageURL) {
        
        if (image) {
            NSLog(@"下载完成");
        }
        
    }];
    
}


-(void)addFMDB
{
    NSString* docsdir = [NSSearchPathForDirectoriesInDomains( NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString* dbpath = [docsdir stringByAppendingPathComponent:@"user.sqlite"];
    
    db = [FMDatabase databaseWithPath:dbpath];
    
    if ([db open]) {
        
        //4.创表
        BOOL result=[db executeUpdate:@"CREATE TABLE IF NOT EXISTS m_user (StoreID text,StoreName text,StoreInventory text);"];
        
        if (result) {
            NSLog(@"创表成功");
            for (int i = 0; i<allData.count; i++) {
                [db executeUpdate:@"INSERT INTO m_user (StoreID,StoreName,StoreInventory) VALUES (?,?,?)",[[allData objectAtIndex:i]objectAtIndex:0],[[allData objectAtIndex:i]objectAtIndex:1],[[allData objectAtIndex:i]objectAtIndex:2]];
            }
        }else{
            NSLog(@"创表失败");
        }
        
        // 1.执行查询语句
        FMResultSet *resultSet = [db executeQuery:@"SELECT * FROM m_user"];
        
        // 2.遍历结果
        while ([resultSet next]) {
            //            NSString * StoreID = [resultSet stringForColumn:@"StoreID"];
            //            NSString *StoreName = [resultSet stringForColumn:@"StoreName"];
            //            NSString *StoreInventory = [resultSet stringForColumn:@"StoreInventory"];
            //            NSLog(@"%@ %@ %@", StoreID, StoreName, StoreInventory);
        }
        
        [db executeUpdate:@"DELETE FROM m_user WHERE StoreName = ?",@"24206"];
        //        [db executeUpdate:@"DELETE FROM m_user;"];
        
    }
}

#pragma mark 拉伸图片至固定宽高
-(UIImage*) OriginImage:(UIImage *)image1 scaleToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    [image1 drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage* scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

#pragma mark 转换成汉字
- (NSString *) changeDictionary:(NSDictionary*)dic
{
    NSString *tempStr1 = [[dic description] stringByReplacingOccurrencesOfString:@"\\u" withString:@"\\U"];
    NSString *tempStr2 = [tempStr1 stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""];
    
    
    
    NSString *tempStr3 = [[@"\"" stringByAppendingString:tempStr2] stringByAppendingString:@"\""];
    NSData *tempData = [tempStr3 dataUsingEncoding:NSUTF8StringEncoding];
    NSString *str = [NSPropertyListSerialization propertyListFromData:tempData mutabilityOption:NSPropertyListImmutable format:NULL errorDescription:NULL];
    
    return str;
}


#pragma mark 数组排序
-(void)arraySort
{
    NSDictionary *dick = @{
                           @"name":@"张三五五",
                           @"age":@"28",
                           @"results":@"371",
                           @"sex":@"男"
                           };
    NSDictionary *dick1 = @{
                            @"name":@"李四一",
                            @"age":@"22",
                            @"results":@"121",
                            @"sex":@"男"
                            };
    NSDictionary *dick2 = @{
                            @"name":@"王五六六六",
                            @"age":@"29",
                            @"results":@"411",
                            @"sex":@"男"
                            };
    NSDictionary *dick3 = @{
                            @"name":@"丁六",
                            @"age":@"21",
                            @"results":@"931",
                            @"sex":@"男"
                            };
    NSMutableArray *array = [NSMutableArray arrayWithObjects:dick,dick1,dick2,dick3, nil];
    
    NSMutableArray *array1 = [NSMutableArray array];
    
    
    //把元素存入对象
    for (int i = 0; i<array.count; i++) {
        Data *data = [[Data alloc]init];
        data.age = [[array objectAtIndex:i]objectForKey:@"name"];
        data.name = [[array objectAtIndex:i]objectForKey:@"age"];
        data.results = [[array objectAtIndex:i]objectForKey:@"results"];
        data.sex = [[array objectAtIndex:i]objectForKey:@"sex"];
        [array1 addObject:data];
    }
    NSLog(@"%@",array1);
    
    
    
    //从对象中取中元素的key值 来排序
    NSSortDescriptor *age = [NSSortDescriptor sortDescriptorWithKey:@"age" ascending:YES];
    
    NSSortDescriptor *results = [NSSortDescriptor sortDescriptorWithKey:@"results" ascending:YES];
    
    NSArray *descs = [NSArray arrayWithObjects:age,results,nil];
    
    NSArray *array2 = [array sortedArrayUsingDescriptors:descs];
    
    NSLog(@"array2:%@", array2);
    
    NSMutableArray *arry3 = [NSMutableArray array];
    
    
    //再把元素转成对象
    for (int i = 0; i<array2.count; i++) {
        Data *data = [[Data alloc]init];
        data.age = [[array objectAtIndex:i]objectForKey:@"name"];
        data.name = [[array objectAtIndex:i]objectForKey:@"age"];
        data.results = [[array objectAtIndex:i]objectForKey:@"results"];
        data.sex = [[array objectAtIndex:i]objectForKey:@"sex"];
        [arry3 addObject:data];
    }
    NSLog(@"%@",arry3);
}







@end
