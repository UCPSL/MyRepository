//
//  ButtonViewController.m
//  ThirdKu1
//
//  Created by ad  on 15-4-3.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "ButtonViewController.h"
#import "UIButton+Bootstrap.h"
@interface ButtonViewController ()

@end

@implementation ButtonViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.defaultButton defaultStyle];
    
    [self.defaultButton.titleLabel setFont:[UIFont systemFontOfSize:12]];
    
    [self.primaryButton primaryStyle];
    [self.successButton successStyle];
    [self.infoButton infoStyle];
    [self.warningButton warningStyle];
    [self.dangerButton dangerStyle];
    
    [self.bookmarkButton primaryStyle];
    [self.bookmarkButton addAwesomeIcon:FAIconBookmark beforeTitle:YES];
    
    [self.doneButton successStyle];
    [self.doneButton addAwesomeIcon:FAIconCheck beforeTitle:NO];
    
    [self.deleteButton dangerStyle];
    [self.deleteButton addAwesomeIcon:FAIconRemove beforeTitle:YES];
    
    [self.downloadButton defaultStyle];
    [self.downloadButton addAwesomeIcon:FAIconDownloadAlt beforeTitle:NO];
    
    [self.calendarButton infoStyle];
    [self.calendarButton addAwesomeIcon:FAIconCalendar beforeTitle:NO];
    
    [self.favoriteButton warningStyle];
    [self.favoriteButton addAwesomeIcon:FAIconStar beforeTitle:NO];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
