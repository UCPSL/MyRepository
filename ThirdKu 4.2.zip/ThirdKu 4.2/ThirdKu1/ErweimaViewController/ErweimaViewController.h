//
//  ErweimaViewController.h
//  ThirdKu1
//
//  Created by ad  on 15-4-1.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarSDK.h"
#import "QRCodeGenerator.h"

@interface ErweimaViewController : UIViewController<UIAlertViewDelegate,UITextFieldDelegate,ZBarReaderViewDelegate>
{
    IBOutlet UITextField *contentext;
    IBOutlet UIButton *createErWei;
    IBOutlet UIImageView *hideErWei;
    IBOutlet UILabel *labe1;
    IBOutlet UIButton *saomiao;
    
//    int num;
//    BOOL upOrdown;
//    NSTimer * timer;
    
}


- (IBAction)createErWei:(id)sender;
- (IBAction)saomiao:(id)sender;

@end
