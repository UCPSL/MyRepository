//
//  RectViewController.m
//  ThirdKu1
//
//  Created by ad  on 15-4-3.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "RectViewController.h"
#import "SHLineGraphView.h"
#import "SHPlot.h"


@interface RectViewController ()


@end

@implementation RectViewController





- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
    SHLineGraphView *_lineGraph = [[SHLineGraphView alloc] initWithFrame:CGRectMake(0, 80, SCREEN_WIDTH, 300)];
    
    [_lineGraph setBackgroundColor:MYColor(250, 203, 14)];
    
    
    
    NSDictionary *_themeAttributes = @{
                                       kXAxisLabelColorKey : [UIColor redColor],
                                       kXAxisLabelFontKey : [UIFont fontWithName:@"TrebuchetMS" size:10],
                                       kYAxisLabelColorKey : [UIColor blueColor],
                                       kYAxisLabelFontKey : [UIFont fontWithName:@"TrebuchetMS" size:10],
                                       kYAxisLabelSideMarginsKey : @10,
                                       kPlotBackgroundLineColorKye : [UIColor greenColor]
                                       };
    
    _lineGraph.themeAttributes = _themeAttributes;
    
    _lineGraph.yAxisRange = @(2000);
    
//    _lineGraph.yAxisSuffix = @"K";
    
    
    _lineGraph.xAxisValues = @[
                               @{ @1 : @"12.5" },
                               @{ @2 : @"12.11" },
                               @{ @3 : @"12.21" },
                               @{ @4 : @"1.21" },
                               @{ @5 : @"2.11" },
                               @{ @6 : @"2.15" }
                               ];
    
    SHPlot *_plot1 = [[SHPlot alloc] init];
    _plot1.plottingValues = @[
                              @{ @1 : @200 },
                              @{ @2 : @1600 },
                              @{ @3 : @400 },
                              @{ @4 : @1100 },
                              @{ @5 : @500 },
                              @{ @6 : @1800 }
                              ];
    NSArray *arr = @[@"1", @"2", @"3", @"4", @"5", @"6"];
    _plot1.plottingPointsLabels = arr;
    
    
    NSDictionary *_plotThemeAttributes = @{
                                           kPlotFillColorKey : [UIColor orangeColor],
                                           kPlotStrokeWidthKey : @2,
                                           kPlotStrokeColorKey : [UIColor purpleColor],
                                           kPlotPointFillColorKey : [UIColor blackColor],
                                           kPlotPointValueFontKey : [UIFont fontWithName:@"TrebuchetMS" size:18]
                                           };
    
    
    _plot1.plotThemeAttributes = _plotThemeAttributes;
    [_lineGraph addPlot:_plot1];
    
    
    [_lineGraph setupTheView];
    
    [self.view addSubview:_lineGraph];
}


@end
