//
//  AlertViewController.h
//  ThirdKu
//
//  Created by ad  on 15-3-23.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SIAlertView.h"
#import "ButtonViewController.h"
#import "RectViewController.h"

@interface AlertViewController : UIViewController
- (IBAction)btn:(UIButton *)sender;

@end
