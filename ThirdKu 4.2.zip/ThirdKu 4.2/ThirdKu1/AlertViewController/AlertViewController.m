//
//  AlertViewController.m
//  ThirdKu
//
//  Created by ad  on 15-3-23.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "AlertViewController.h"

@interface AlertViewController ()



@end

@implementation AlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}


- (IBAction)btn:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    if (sender.tag == 1) [self alertView1];
    else if (sender.tag == 2) [self alertView2];
    else if (sender.tag == 3) [self alertView3];
    else if (sender.tag == 4) [self.navigationController pushViewController:[[ButtonViewController alloc]init] animated:YES];
    else if (sender.tag == 5) [self.navigationController pushViewController:[[RectViewController alloc]init] animated:YES];
    
    
    
}





-(void)alertView1
{
    SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:@"提示" andMessage:@"对不起,你的余额不足"];
    [alertView addButtonWithTitle:@"确定"
                             type:SIAlertViewButtonTypeDefault
                          handler:^(SIAlertView *alertView) {
                              NSLog(@"确定，你的余额不足");
                          }];
    [alertView show];
}

-(void)alertView2
{
    SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:@"Title2" andMessage:@"Message2"];
    
    [alertView addButtonWithTitle:@"Cancel"
                             type:SIAlertViewButtonTypeCancel
                          handler:^(SIAlertView *alertView) {
                              NSLog(@"取消");
                          }];
    
    [alertView addButtonWithTitle:@"OK"
                             type:SIAlertViewButtonTypeDefault
                          handler:^(SIAlertView *alertView) {
                              NSLog(@"确定");
                          }];
    alertView.titleColor = [UIColor blueColor];
    alertView.cornerRadius = 10;
    alertView.buttonFont = [UIFont boldSystemFontOfSize:15];
    alertView.transitionStyle = SIAlertViewTransitionStyleBounce;
    
    alertView.willShowHandler = ^(SIAlertView *alertView) {
        NSLog(@"我要出来了");
    };
    alertView.didShowHandler = ^(SIAlertView *alertView) {
        NSLog(@"我已经出来了");
    };
    alertView.willDismissHandler = ^(SIAlertView *alertView) {
        NSLog(@"我要消失了");
    };
    alertView.didDismissHandler = ^(SIAlertView *alertView) {
        NSLog(@"我已经消失了");
    };
    
    [alertView show];
}

-(void)alertView3
{
    SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:nil andMessage:@"Message3"];
    
    [alertView addButtonWithTitle:@"Cancel"
                             type:SIAlertViewButtonTypeCancel
                          handler:^(SIAlertView *alertView) {
                              NSLog(@"取消");
                          }];
    
    [alertView addButtonWithTitle:@"OK"
                             type:SIAlertViewButtonTypeDefault
                          handler:^(SIAlertView *alertView) {
                              NSLog(@"确定");
                          }];
    alertView.transitionStyle = SIAlertViewTransitionStyleDropDown;
    alertView.backgroundStyle = SIAlertViewBackgroundStyleSolid;
    
    alertView.willShowHandler = ^(SIAlertView *alertView) {
        NSLog(@"%@, willShowHandler3", alertView);
    };
    alertView.didShowHandler = ^(SIAlertView *alertView) {
        NSLog(@"%@, didShowHandler3", alertView);
    };
    alertView.willDismissHandler = ^(SIAlertView *alertView) {
        NSLog(@"%@, willDismissHandler3", alertView);
    };
    alertView.didDismissHandler = ^(SIAlertView *alertView) {
        NSLog(@"%@, didDismissHandler3", alertView);
    };
    [alertView show];

}


@end
