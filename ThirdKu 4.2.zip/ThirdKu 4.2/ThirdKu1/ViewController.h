//
//  ViewController.h
//  ThirdKu
//
//  Created by ad  on 15-3-16.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CycleScrollView.h"     //滚动图片
#import "SMPageControl.h"       //pageView
#import "MONActivityIndicatorView.h"    //加载指示器
#import "MyTabelTableViewController.h"  //上拉刷新下拉加载

#import "Demo1ViewController.h"        //界面弹出说明

#import "FMDatabase.h"
#import "AlertViewController.h"

#import "Data.h"

@interface ViewController : UIViewController<CycleScrollViewDelegate,MONActivityIndicatorViewDelegate>



//判断网络
typedef enum {
    NETWORK_TYPE_NONE= 0,
    NETWORK_TYPE_2G= 1,
    NETWORK_TYPE_3G= 2,
    NETWORK_TYPE_4G= 3,
    NETWORK_TYPE_5G= 4,//  5G目前为猜测结果
    NETWORK_TYPE_WIFI= 5,
}NETWORK_TYPE;

+(NETWORK_TYPE)getNetworkTypeFromStatusBar;

@end

