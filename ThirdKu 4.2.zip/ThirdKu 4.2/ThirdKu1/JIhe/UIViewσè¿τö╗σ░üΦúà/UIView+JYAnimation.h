//
//  UIView+JYAnimation.h
//
//  Created by mac on 15-1-7.
//  Copyright (c) 2015年 lijianyi. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef enum{
    JYAnimationShakeViewDirectionX,
    JYAnimationShakeViewDirectionY,
    JYAnimationShakeViewDirectionXYLeft,
    JYAnimationShakeViewDirectionXYRight
}JYAnimationShakeViewDirection;


@interface UIView (JYAnimation)
@property (assign, nonatomic) CGFloat x;
@property (assign, nonatomic) CGFloat y;
@property (assign, nonatomic) CGFloat width;
@property (assign, nonatomic) CGFloat height;
@property (assign, nonatomic) CGSize size;
@property (assign, nonatomic) CGPoint origin;
@property (assign, nonatomic) CGFloat centerX;
@property (assign, nonatomic) CGFloat centerY;


/**
 *  方向抖动
 *
 *  @param view        抖动的VIEW
 *  @param distance    抖动的距离
 *  @param time        抖动的时间
 *  @param repeatCount 抖动的次数
 *  @param direction   抖动的方向
 */
+(void)shakeViewAnimation:(UIView *)view andDistace:(CGFloat)distance andDuration:(NSTimeInterval)time andRepeateCount:(NSInteger)repeatCount andDirection:(JYAnimationShakeViewDirection)direction;
/**
 *  隐式动画（自定义layer，替换系统的,默认layer的锚点是（0，0））
 *
 *  @param view     执行隐式动画的view
 *  @param boundes  layer的大小
 *  @param color    layer的颜色
 *  @param position layer的位置
 *  @param opcity   layer的不透明度
 */
+(void)hidenViewAnimation:(UIView *)view andLayerBoundes:(CGRect)boundes andLayerBackgroundColor:(UIColor*)color andPosition:(CGPoint)position andOpcity:(CGFloat)opcity;
/**
 *  条纹背景
 *
 *  @param view         需要条纹背景的view
 *  @param stritatHight 条纹高度
 *  @param striateColor 条纹颜色
 *  @param lineHight    线的高度
 *  @param lineColor    线的颜色
 */
+(void)striatedView:(UIView *)view andStriatHight:(CGFloat)stritatHight andStriateColor:(UIColor*)striateColor andLineHight:(CGFloat)lineHight andLineColor:(UIColor*)lineColor;
/**
 *  抖动
 *
 *  @param view        抖动的view
 *  @param angel       抖动的弧度
 *  @param time        动画时间
 *  @param repeatCount 重复次数
 *  @param save        是否保存动画
 */
+(void)shakView:(UIView*)view andAngel:(CGFloat)angel andDuration:(NSTimeInterval)time andRepeatCount:(NSInteger)repeatCount andSave:(BOOL)save;
/**
 *  UIImageView 帧动画
 *
 *  @param imageView              执行动画的imageView
 *  @param iamgeName              图片名字的共同部分
 *  @param formatter              图片格式
 *  @param count                  每组图片的张数
 */
+(void)imageViewKeyAnimation:(UIImageView*) imageView andImageName:(NSString*) iamgeName andImageFormatter:(NSString*) formatter andImageCount:(NSInteger)count;
/**
 *  平移动画
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param tx   x方向的平移量
 *  @param ty   y方向的平移量
 *  @param resume   NO:平移一次 YES:持续平移（基于上一次的位置继续平移）
 */
+(void)translationAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeX:(CGFloat) tx andChangeY:(CGFloat) ty andResume:(BOOL) resume;
/**
 *  缩放动画
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param sx   x方向的缩放倍数
 *  @param sy   y方向的缩放倍数
 *  @param resume   NO:缩放一次 YES:持续缩放（基于上一次的位置继续缩放）
 */
+(void)scaleAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeX:(CGFloat) sx andChangeY:(CGFloat) sy andResume:(BOOL) resume;
/**
 *  2D旋转动画
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param angel 旋转的角度(0-180，顺时针旋转 -180-0 ，逆时针旋转,(180&-180都是顺时针旋转))
 *  @param resume   NO:旋转一次 YES:持续旋转（基于上一次的位置继续旋转）
 */
+(void)rotation2DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andResume:(BOOL) resume;
/**
 *  CABasicAnimation，2D旋转动画
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param angel 旋转的角度（+顺时针旋转,-逆时针旋转）
 *  @param save   YES:表示保留动画 NO:表示不保留动画(控件会回到最初的位置)
 */
+(void)rotation2DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andSave:(BOOL) save;
/**
 *    CABasicAnimation，基本动画，3D旋转动画
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param angel 旋转的角度
 *  @param x     将要旋转到得x点
 *  @param y     将要旋转到得y点
 *  @param z     将要旋转到得z点
 *  @param save  YES:表示保留动画 NO:表示不保留动画
 */
+(void)rotation3DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andToX :(CGFloat)x andToY:(CGFloat)y andToZ:(CGFloat)z andSave:(BOOL) save;
/**
 *  UIRotationGestureRecognizer,旋转手势
 */
-(void)rotationGestureAnimation;
/**
 *  轻扫手势
 *
 *  @param direction 手势方向
 */
-(void)swipeGestureAnimation:(UISwipeGestureRecognizerDirection)direction;
/**
 *  捏合手势（缩放）
 */
-(void)pinGestureAnimation;
/**
 *  拖拽手势（拖哪里到哪里）
 */
-(void)panGestureAnimation;
/**
 *  敲击手势
 *
 *  @param fingers 敲击手指个数
 *  @param count   敲击次数
 */
-(void)tapGestureAnimation:(NSInteger)fingers andTapCount:(NSInteger)count;
/**
 *  长按手势
 *
 *  @param fingers 长按时手指个数
 *  @param time    长按时间
 */
-(void)longPressGestureAnimation:(NSInteger)fingers andDuration:(NSTimeInterval)time;
/**
 *  CAKeyframeAnimation关键帧动画，走不同的位置,使用的是默认锚点
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param values 存储位置的数组
 *  @param save   YES:表示保留动画 NO:表示不保留动画
 */
+(void)keyValuesAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andValues:(NSArray*)values andSave:(BOOL) save;
/**
 *  CAKeyframeAnimation关键帧动画，走指定路径，使用的是默认锚点
 *
 *  @param view 执行动画的view
 *  @param time 动画时间
 *  @param rectt 将要绘制椭圆/圆路径的矩形
 *  @param save  YES:表示保留动画 NO:表示不保留动画
 */
+(void)keyPathAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andRect:(CGRect) rectt andSave:(BOOL) save;
/**
 *  CAAnimationGroup 组动画，执行一组动画,动画时间是所有动画的时间和
 *
 *  @param view 执行动画的view
 *  @param animations 要执行的动画的数组
 *  @param save     YES:表示保留动画 NO:表示不保留动画
 */
+(void)groupAnimationWith:(UIView *)view andAnimations:(NSArray*)animations andSave:(BOOL) save;
/**
 *  阴影
 *
 *  @param view    需要产生阴影的view
 *  @param color   阴影颜色
 *  @param size    阴影大小
 *  @param opacity 不透明度（默认是透明的：0）（0--1.0）
 */
+(void)shadowWith:(UIView *)view andShadowColor:(UIColor*)color andSize:(CGSize)size andOpacity:(CGFloat)opacity;
/**
 *  圆角
 *
 *  @param view 需要产生圆角的view
 *  @param angel 圆角大小
 */
+(void)cornerWith:(UIView *)view andAngel:(CGFloat)angel;

/**
 *  边框
 *
 *  @param view 需要产生边框的view
 *  @param borderWidth 边框宽度
 *  @param borderColor 边框颜色
 */
+(void)borderWith:(UIView *)view andBorderWidth:(CGFloat)borderWidth andBorderColor:(UIColor*)borderColor;
@end
