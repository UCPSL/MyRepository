//
//  UIView+JYAnimation.m
//
//  Created by mac on 15-1-7.
//  Copyright (c) 2015年 lijianyi. All rights reserved.
//

#import "UIView+JYAnimation.h"

#define ANGLE_TO_RADIAN(angle) ((angle)/180.0 * M_PI)

@implementation UIView (JYAnimation)
#pragma mark viewFrame的直接获取
- (void)setX:(CGFloat)x
{
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (CGFloat)x
{
    return self.frame.origin.x;
}

- (void)setY:(CGFloat)y
{
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)y
{
    return self.frame.origin.y;
}

- (void)setWidth:(CGFloat)width
{
    CGRect frame = self.frame;
    frame.size.width = width;
    self.frame = frame;
}

- (CGFloat)width
{
    return self.frame.size.width;
}

- (void)setHeight:(CGFloat)height
{
    CGRect frame = self.frame;
    frame.size.height = height;
    self.frame = frame;
}

- (CGFloat)height
{
    return self.frame.size.height;
}

- (void)setSize:(CGSize)size
{
    CGRect frame = self.frame;
    frame.size = size;
    self.frame = frame;
}

- (CGSize)size
{
    return self.frame.size;
}

- (void)setOrigin:(CGPoint)origin
{
    CGRect frame = self.frame;
    frame.origin = origin;
    self.frame = frame;
}

- (CGPoint)origin
{
    return self.frame.origin;
}
- (void)setCenterX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)centerX
{
    return self.center.x;
}

- (void)setCenterY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)centerY
{
    return self.center.y;
}
#pragma mark view的旋转抖动
+(void)shakView:(UIView*)view andAngel:(CGFloat)angel andDuration:(NSTimeInterval)time andRepeatCount:(NSInteger)repeatCount andSave:(BOOL)save{
    //    1.创建
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.rotation"];
    
    //    设置
    anim.duration = time;
    
    anim.repeatCount = repeatCount;
    
    
    anim.values = @[@(ANGLE_TO_RADIAN(-angel)), @(ANGLE_TO_RADIAN(angel)), @(ANGLE_TO_RADIAN(-angel))];
    
    if (save) {
        //        保留动画
        anim.removedOnCompletion=NO;
        anim.fillMode=kCAFillModeForwards;
    }
    
    //    2.添加
    [view.layer addAnimation:anim forKey:@"shake"];
}


#pragma mark view的方向抖动
+(void)shakeViewAnimation:(UIView *)view andDistace:(CGFloat)distance andDuration:(NSTimeInterval)time andRepeateCount:(NSInteger)repeatCount andDirection:(JYAnimationShakeViewDirection)direction{
    
    //    1.创建
    CAKeyframeAnimation *anim = [CAKeyframeAnimation animationWithKeyPath:@"transform.translation"];
    
    //    设置
    anim.duration = time;
    anim.repeatCount = repeatCount;
    //    计算值
    CGFloat Ay=0;
    CGFloat Ax=0;
    
    if (direction==JYAnimationShakeViewDirectionX) {

        
        NSValue* v1=[NSValue valueWithCGPoint:CGPointMake(Ax-distance, Ay)];
        NSValue* v2=[NSValue valueWithCGPoint:CGPointMake(Ax, Ay)];
        NSValue* v3=[NSValue valueWithCGPoint:CGPointMake(Ax+distance, Ay)];
        
        anim.values=@[v1,v2,v3,v2];

    }else if (direction==JYAnimationShakeViewDirectionY){
        
        NSValue* v1=[NSValue valueWithCGPoint:CGPointMake(Ax,Ay-distance)];
        NSValue* v2=[NSValue valueWithCGPoint:CGPointMake(Ax,Ay)];
        NSValue* v3=[NSValue valueWithCGPoint:CGPointMake(Ax,Ay+distance)];
        
        anim.values=@[v1,v2,v3,v2];
    }else if (direction==JYAnimationShakeViewDirectionXYLeft){
        
        NSValue* v1=[NSValue valueWithCGPoint:CGPointMake(Ax-distance,Ay-distance)];
        NSValue* v2=[NSValue valueWithCGPoint:CGPointMake(Ax,Ay)];
        NSValue* v3=[NSValue valueWithCGPoint:CGPointMake(Ax+distance,Ay+distance)];
        
        anim.values=@[v1,v2,v3,v2];
    }else if (direction==JYAnimationShakeViewDirectionXYRight){
        
        NSValue* v1=[NSValue valueWithCGPoint:CGPointMake(Ax+distance,Ay-distance)];
        NSValue* v2=[NSValue valueWithCGPoint:CGPointMake(Ax,Ay)];
        NSValue* v3=[NSValue valueWithCGPoint:CGPointMake(Ax-distance,Ay+distance)];
        
        anim.values=@[v1,v2,v3,v2];
    }

    //    2.添加
    [view.layer addAnimation:anim forKey:nil];

    
    
}
#pragma mark view的隐式动画
+(void)hidenViewAnimation:(UIView *)view andLayerBoundes:(CGRect)boundes andLayerBackgroundColor:(UIColor*)color andPosition:(CGPoint)position andOpcity:(CGFloat)opcity{
    
    CALayer* layer=[CALayer layer];
//    指定layer的bounds
    layer.bounds = boundes;
//    设置layer的锚点
    layer.anchorPoint = CGPointZero;
//    添加layer
    [view.layer addSublayer:layer];
//    KVC 替换view的layer
    [view setValue:layer forKeyPath:@"layer"];


    
    
    [CATransaction begin]; // 开始事务
    [CATransaction setDisableActions:YES];
    
    view.layer.backgroundColor = color.CGColor;
    view.layer.position = position;
    
    // 不透明度
    view.layer.opacity = opcity;
    
    [CATransaction commit];// 提交事务


    
    
}
#pragma mark view的条纹背景
+(void)striatedView:(UIView *)view andStriatHight:(CGFloat)stritatHight andStriateColor:(UIColor*)striateColor andLineHight:(CGFloat)lineHight andLineColor:(UIColor*)lineColor{
   
    // 1. 生成一个用于平铺的小图片
    CGSize size = CGSizeMake(view.frame.size.width, stritatHight);
    
    // 2. 初始化一个bitmap对应的图形上下文, 大小跟我最后要生成的格子图片大小一样
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    // 3. 画矩形
    // 3.1 获得当前的上下文
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    // 3.2 绘图(画矩形)
    CGContextAddRect(ctx, CGRectMake(0, 0, size.width, stritatHight));
    // 3.3 设置颜色
    [striateColor set];
    // 3.4 把矩形渲染到图行上下文中
    CGContextFillPath(ctx);
    
    // 4. 画线条
   
    CGFloat lineY = stritatHight - lineHight;
    CGFloat lineX = 0;
    // 4.1 在左下角开始起点
    CGContextMoveToPoint(ctx, lineX, lineY);
    // 4.2 从左下角开始跟终点连成一根线
    CGContextAddLineToPoint(ctx, size.width, lineY);
    // 4.3 设置线条颜色
    [lineColor set];
    // 4.4 把这根线渲染到图形上下文
    CGContextStrokePath(ctx);
    
    // 5. 从bitmap的图形上下文中取出image对象
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    // 6. 结束上下文
    UIGraphicsEndImageContext();
    
    // 7. 通过小格子初始化一个颜色,并且设置为view的背景颜色(默认拿小格子进行填充)
    view.backgroundColor = [UIColor colorWithPatternImage:image];

    
    
}
#pragma mark UIPanGestureRecognizer(拖拽))
/**
 *  拖拽
 */
-(void)panGestureAnimation{
    //    1.创建拖拽手势
    UIPanGestureRecognizer* pan=[[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(panAction:)];
    //    2.添加手势
    [self addGestureRecognizer:pan];
    
    
}
/**
 *  拖拽手势触发的方法
 */
-(void)panAction:(UIPanGestureRecognizer*)pan{
    /**
     *  要做的处理
     */
    
    //    偏移量
    CGPoint point=[pan translationInView:self];
    //    偏移
    self.transform = CGAffineTransformTranslate(self.transform, point.x, point.y);
    //    偏移量清零，系统不会清零，会累加偏移量 pan.view pan手势所在的view（在这里其实是self）
    [pan setTranslation:CGPointZero inView:self];
    
    //        手势结束
    if (pan.state==UIGestureRecognizerStateEnded) {
        
        self.backgroundColor=[UIColor redColor];
    }
}

#pragma mark UILongPressGestureRecognizer(长按)
/**
 *  长按
 */
-(void)longPressGestureAnimation:(NSInteger)fingers andDuration:(NSTimeInterval)time{
    //    1.创建长按手势
    UILongPressGestureRecognizer* longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressAction:)];
    //    设置
    longPress.numberOfTouchesRequired=fingers;//手指个数
    longPress.minimumPressDuration=time;//手势被识别的最短时间，默认是0.5
    //    2.添加手势
    [self addGestureRecognizer:longPress];
    
}
/**
 *  长按手势触发的方法
 */
-(void)longPressAction:(UILongPressGestureRecognizer*)longPress{
    
    /**
     *  要做的处理，示例阴影
     */

    [UIView shadowWith:self andShadowColor:[UIColor redColor] andSize:CGSizeMake(5, 5) andOpacity:0.5];
    
    //    手势结束
    if (longPress.state==UIGestureRecognizerStateEnded) {
        
        self.backgroundColor=[UIColor blackColor];
    }
    
}

#pragma mark UITapGestureRecognizer(敲击)
/**
 *  敲击
 */
-(void)tapGestureAnimation:(NSInteger)fingers andTapCount:(NSInteger)count{
    //    1.创建单击手势
    UITapGestureRecognizer* tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    //    2.设置
    tap.numberOfTapsRequired=count;//敲击次数
    tap.numberOfTouchesRequired=fingers;//两根手指
    //    3.添加手势
    [self addGestureRecognizer:tap];
}
/**
 *  敲击手势触发的方法
 */
-(void)tapAction:(UITapGestureRecognizer*)tap{
    /**
     *  要做的处理，示例改变背景色
     */

    
    self.backgroundColor=[UIColor redColor];
    
    //    手势结束
    if (tap.state==UIGestureRecognizerStateEnded) {
        
    }
    
}

#pragma mark UIPinchGestureRecognizer(捏合,⽤用于缩放)
/**
 *  捏合
 */
-(void)pinGestureAnimation{
    //    1.创建捏合手势
    UIPinchGestureRecognizer* pin=[[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(pinAction:)];
    //    2.添加手势
    [self addGestureRecognizer:pin];
    
    
}
/**
 *  捏合手势触发的方法
 */
-(void)pinAction:(UIPinchGestureRecognizer*)pin{
    /**
     *  要做的处理，示例缩放
     */

    self.transform=CGAffineTransformScale(self.transform, pin.scale, pin.scale);
    //    手势结束
    if (pin.state==UIGestureRecognizerStateEnded) {
        
        self.backgroundColor=[UIColor blackColor];
    }
    //    指定缩放，不再变化
    //    pin.scale=1;
}


#pragma mark UISwipeGestureRecognizer(轻扫手势)
/**
 *  轻扫
 */
-(void)swipeGestureAnimation:(UISwipeGestureRecognizerDirection)direction{
    
        //    1.创建轻扫手势
    UISwipeGestureRecognizer* swipe=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeAction:)];
   
    //    设置（轻扫方向）
    swipe.direction=direction;
    //    2.添加手势
    [self addGestureRecognizer:swipe];
    
   
    
    
}
/**
 *  轻扫手势触发的方法
 */
-(void)swipeAction:(UISwipeGestureRecognizer*)swipe{
    
    /**
     *  要做的处理，示例改变背景色
     */
    self.backgroundColor=[UIColor grayColor];
    //    手势结束
    if (swipe.state==UIGestureRecognizerStateEnded) {
        
        self.backgroundColor=[UIColor blackColor];
    }
    
}


#pragma mark UIRotationGestureRecognizer(旋转)
-(void)rotationGestureAnimation{
     //    1.创建旋转手势
     UIRotationGestureRecognizer* rotation=[[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(rotationAction:)];
    //    2.添加手势
    [self addGestureRecognizer:rotation];
}
/**
 *  旋转手势触发的方法
 */
-(void)rotationAction:(UIRotationGestureRecognizer*)rotation{
    
    /**
     *  要做的处理，示例旋转
     */

    self.transform=CGAffineTransformRotate(self.transform, rotation.rotation);
    //    手势结束
    if (rotation.state==UIGestureRecognizerStateEnded) {
        
//        view.backgroundColor=[UIColor blackColor];
    }
    
}
#pragma mark UIImageView(帧动画)
+(void)imageViewKeyAnimation:(UIImageView *)imageView andImageName:(NSString *)iamgeName  andImageFormatter:(NSString*) formatter andImageCount:(NSInteger)count{
    
    NSMutableArray* images=[NSMutableArray array];//创建数组存储数据
    
    //循环添加图片：加载文件到内存
    for (int i=0; i<count; i++) {
        
        images[i]=[UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@%02d.%@",iamgeName,i,formatter] ofType:nil]];//不使用缓存，不断覆盖
    }
    
    
    //    选定图片集
    imageView.animationImages=[images copy];//copy是为了防止影响选定执行动画的图片集
    
    //    设置时间
    imageView.animationDuration=images.count*0.1;
    
    //    开启动画
    [imageView startAnimating];
    
    
    
    //    清理内存
    [imageView performSelector:@selector(stopAnimating) withObject:nil afterDelay:images.count*0.1];
}
#pragma mark (平移)
+(void)translationAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeX:(CGFloat) tx andChangeY:(CGFloat) ty andResume:(BOOL) resume{
    
    [self animateWithDuration:time animations:^{
        if (resume) {
             view.transform=CGAffineTransformTranslate(view.transform, tx, ty);
        } else {
            view.transform=CGAffineTransformMakeTranslation(tx, ty);
        }
       
    }];
    
}
#pragma mark (缩放)
+(void)scaleAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeX:(CGFloat)sx andChangeY:(CGFloat)sy andResume:(BOOL) resume{
    
    [self animateWithDuration:time animations:^{
        if (resume) {
             view.transform=CGAffineTransformScale(view.transform,sx, sy);
        } else {
            view.transform=CGAffineTransformMakeScale(sx, sy);
        }
        
       
    }];
}
#pragma mark (非手势旋转)
+(void)rotation2DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andResume:(BOOL) resume{

    [self animateWithDuration:time animations:^{
    
        if (resume) {
            view.transform=CGAffineTransformRotate(view.transform, ANGLE_TO_RADIAN(angel));
        } else {
            view.transform=CGAffineTransformMakeRotation(ANGLE_TO_RADIAN(angel));
        }
        
        
    }];
}
+(void)rotation2DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andSave:(BOOL)save{
//    1.创建
    CABasicAnimation* anima=[CABasicAnimation animationWithKeyPath:@"transform.rotation"];
//    2.设置
    anima.duration=time;
    anima.toValue=@(ANGLE_TO_RADIAN(angel));
    
    if (save) {
        //        保留动画
        anima.removedOnCompletion=NO;
        anima.fillMode=kCAFillModeForwards;
    }
//   3.添加
    [view.layer addAnimation:anima forKey:nil];

    
    
}
+(void)rotation3DAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andChangeAngel:(CGFloat)angel andToX :(CGFloat)x andToY:(CGFloat)y andToZ:(CGFloat)z andSave:(BOOL) save{
    
//   1.创建
    CABasicAnimation* anima=[CABasicAnimation animationWithKeyPath:@"transform"];
//    2.设置
    anima.toValue=[NSValue valueWithCATransform3D:CATransform3DMakeRotation(ANGLE_TO_RADIAN(angel), x,y,z)];
    anima.duration=time;
    
    if (save) {
//        保留动画
        anima.removedOnCompletion=NO;
        anima.fillMode=kCAFillModeForwards;
    }
    
//   3.添加
    [view.layer addAnimation:anima forKey:nil];

    
    
}
#pragma mark CAKeyframeAnimation(关键帧动画)
+(void)keyValuesAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andValues:(NSArray*)values andSave:(BOOL) save{
    
    
//    1.创建
    CAKeyframeAnimation* anima=[CAKeyframeAnimation animationWithKeyPath:@"position"];
//   2.设置
    anima.values=values;
    
    if (save) {
        //        保留动画
        anima.removedOnCompletion=NO;
        anima.fillMode=kCAFillModeForwards;
    }
    
//   3.添加
    [view.layer addAnimation:anima forKey:nil];
    
}
+(void)keyPathAnimationWith:(UIView *)view andDuration:(NSTimeInterval)time andRect:(CGRect)rectt andSave:(BOOL)save{
//    1.创建路径
    CGMutablePathRef path=CGPathCreateMutable();
//    2.绘制圆/椭圆
    CGPathAddEllipseInRect(path, NULL,rectt);
//    --1.创建动画
    CAKeyframeAnimation* anima=[CAKeyframeAnimation animationWithKeyPath:@"position"];
//    --2.设置
    anima.duration=time;
//    anima.repeatCount=2;
//    3.指定动画路径
    anima.path=path;
    
    
    if (save) {
        //        保留动画
        anima.removedOnCompletion=NO;
        anima.fillMode=kCAFillModeForwards;
    }

    
   
//    --3.添加动画
    [view.layer addAnimation:anima forKey:nil];
    
    
//    4.移除路径
    CGPathRelease(path);
}
#pragma mark CAAnimationGroup(组动画)
+(void)groupAnimationWith:(UIView *)view andAnimations:(NSArray *)animations andSave:(BOOL)save{
//    1.创建
    CAAnimationGroup* group=[CAAnimationGroup animation];
//    2.设置
    
    for (CAAnimation* animation in animations) {
        group.duration+=animation.duration;
    }
    
    group.animations=animations;
    
    if (save) {
        //        保留动画
        group.removedOnCompletion=NO;
        group.fillMode=kCAFillModeForwards;
    }

    
//   3. 添加到layer
    [view.layer addAnimation:group forKey:nil];

    
}
#pragma mark (阴影&圆角&边框)

+(void)shadowWith:(UIView *)view andShadowColor:(UIColor*)color andSize:(CGSize)size andOpacity:(CGFloat)opacity{
    
    CALayer* layer=view.layer;
    // 阴影
    layer.shadowColor=color.CGColor;
    layer.shadowOffset=size;
    layer.shadowOpacity=opacity;//默人是透明的
}
+(void)cornerWith:(UIView *)view andAngel:(CGFloat)angel{
    CALayer* layer=view.layer;
    //    圆角
    layer.cornerRadius=angel;
    layer.masksToBounds=YES;
    
}
+(void)borderWith:(UIView *)view andBorderWidth:(CGFloat)borderWidth andBorderColor:(UIColor*)borderColor{
    CALayer* layer=view.layer;
    //边框
    layer.borderWidth=borderWidth;
    layer.borderColor=borderColor.CGColor;
    
}
@end
