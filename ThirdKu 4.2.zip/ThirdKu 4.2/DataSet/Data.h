//
//  Data.h
//  ThirdKu
//
//  Created by ad  on 15-3-25.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Data : NSObject

@property (nonatomic,copy)NSString *name;
@property (nonatomic,copy)NSString *age;
@property (nonatomic,copy)NSString *results;
@property (nonatomic,copy)NSString *sex;

-(id)initWithDick:(NSArray *)array;

@end
