//
//  XMLDataViewController.m
//  ThirdKu
//
//  Created by ad  on 15-3-25.
//  Copyright (c) 2015年 qianhang. All rights reserved.
//

#import "XMLDataViewController.h"

@implementation XMLDataViewController
{
    UITableView *_myTabelView;
}

-(void)viewDidLoad
{
    
}



//
//- (void)sortUsingDescriptors:(NSMutableArray *)sortDescriptors
//{
//    Product *obj = [[Product alloc] init];
//    NSMutableArray *allDataArray = [NSMutableArray array];
//    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:obj.stock_status ascending:YES];
//    [allDataArray sortUsingDescriptors:[NSArray arrayWithObject:sort]];
//    return allDataArray;
//}


@end
