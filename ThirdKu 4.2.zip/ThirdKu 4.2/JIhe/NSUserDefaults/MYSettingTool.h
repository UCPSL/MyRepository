//
//  MYSettingTool.h
//  网易彩票山寨版
//
//  Created by Ucpsl on 14-8-22.
//  Copyright (c) 2014年 UCPSL. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MYSettingTool : NSObject
+ (id)objectForKey:(NSString *)defaultName;
+ (void)setObject:(id)value forKey:(NSString *)defaultName;

+ (BOOL)boolForKey:(NSString *)defaultName;
+ (void)setBool:(BOOL)value forKey:(NSString *)defaultName;

@end
