//
//  MYSettingTool.m
//  网易彩票山寨版
//
//  Created by Ucpsl on 14-8-22.
//  Copyright (c) 2014年 UCPSL. All rights reserved.
//

#import "MYSettingTool.h"

@implementation MYSettingTool

+ (void)setObject:(id)value forKey:(NSString *)defaultName
{
    return [[NSUserDefaults standardUserDefaults]setObject:value forKey:defaultName];
    [[NSUserDefaults standardUserDefaults]synchronize];
}

+ (id)objectForKey:(NSString *)defaultName
{
    return [[NSUserDefaults standardUserDefaults]objectForKey:defaultName];
}


+ (void)setBool:(BOOL)value forKey:(NSString *)defaultName
{
    return [[NSUserDefaults standardUserDefaults]setBool:value forKey:defaultName];
    [[NSUserDefaults standardUserDefaults]synchronize];
}


+ (BOOL)boolForKey:(NSString *)defaultName
{
    return [[NSUserDefaults standardUserDefaults]boolForKey:defaultName];
}


@end
