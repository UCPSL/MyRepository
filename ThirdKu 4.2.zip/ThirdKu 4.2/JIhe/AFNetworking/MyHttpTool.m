//
//  MyHttpTool.m
//  Cooking
//
//  Created by Apple on 14-9-15.
//  Copyright (c) 2014年 qianhang. All rights reserved.
//

#import "MyHttpTool.h"


@implementation MyHttpTool

+(void)requestWithBaseURL:(NSString *)baseURL Path:(NSString *)path params:(NSDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure method:(NSString *)method
{
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:baseURL]];
    
    NSURLRequest *post=[client requestWithMethod:method path:path parameters:params];
    
    NSOperation *op=[AFJSONRequestOperation JSONRequestOperationWithRequest:post success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {
        success(JSON);
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
        failure(error);
    }];
    
    //兼容text和html模式
    [AFJSONRequestOperation addAcceptableContentTypes:[NSSet setWithObject:@"text/html"]];
    
    [op start];
}


+(void)postWithBaseURL:(NSString *)baseURL Path:(NSString *)path params:(NSDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure
{
    [self requestWithBaseURL:baseURL Path:path params:params success:success failure:failure method:@"POST"];
}

+(void)getWithBaseURL:(NSString *)baseURL Path:(NSString *)path params:(NSDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure
{
    [self requestWithBaseURL:baseURL Path:path params:params success:success failure:failure method:@"GET"];
}

@end
