//
//  MyHttpTool.h
//  Cooking
//
//  Created by Apple on 14-9-15.
//  Copyright (c) 2014年 qianhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"


typedef void(^SuccessBlock)(id JSON);
typedef void(^FailureBlock)(NSError *error);

@interface MyHttpTool : NSObject

+(void)getWithBaseURL:(NSString *)baseURL Path:(NSString *)path params:(NSDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure;

+(void)postWithBaseURL:(NSString *)baseURL Path:(NSString *)path params:(NSDictionary *)params success:(SuccessBlock)success failure:(FailureBlock)failure;


@end


